﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.funzione_tb = New System.Windows.Forms.TextBox()
        Me.a_tb = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.calcola_bt = New System.Windows.Forms.Button()
        Me.output_lb = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.aiuto_gb = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.output2_lb = New System.Windows.Forms.Label()
        Me.aiuto_gb.SuspendLayout()
        Me.SuspendLayout()
        '
        'funzione_tb
        '
        Me.funzione_tb.Location = New System.Drawing.Point(73, 15)
        Me.funzione_tb.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.funzione_tb.Name = "funzione_tb"
        Me.funzione_tb.Size = New System.Drawing.Size(564, 31)
        Me.funzione_tb.TabIndex = 0
        Me.funzione_tb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'a_tb
        '
        Me.a_tb.Location = New System.Drawing.Point(47, 65)
        Me.a_tb.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.a_tb.Name = "a_tb"
        Me.a_tb.Size = New System.Drawing.Size(103, 31)
        Me.a_tb.TabIndex = 2
        Me.a_tb.Text = "0"
        Me.a_tb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 18)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 25)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "f(x)="
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 68)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 25)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "x="
        '
        'calcola_bt
        '
        Me.calcola_bt.Location = New System.Drawing.Point(521, 58)
        Me.calcola_bt.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.calcola_bt.Name = "calcola_bt"
        Me.calcola_bt.Size = New System.Drawing.Size(120, 45)
        Me.calcola_bt.TabIndex = 6
        Me.calcola_bt.Text = "Aiuto"
        Me.calcola_bt.UseVisualStyleBackColor = True
        '
        'output_lb
        '
        Me.output_lb.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.output_lb.Location = New System.Drawing.Point(156, 68)
        Me.output_lb.Name = "output_lb"
        Me.output_lb.Size = New System.Drawing.Size(359, 25)
        Me.output_lb.TabIndex = 8
        Me.output_lb.Text = "Inserisci la funzione"
        Me.output_lb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(603, 325)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = resources.GetString("Label1.Text")
        '
        'aiuto_gb
        '
        Me.aiuto_gb.Controls.Add(Me.Label5)
        Me.aiuto_gb.Controls.Add(Me.Label1)
        Me.aiuto_gb.Location = New System.Drawing.Point(12, 153)
        Me.aiuto_gb.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.aiuto_gb.Name = "aiuto_gb"
        Me.aiuto_gb.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.aiuto_gb.Size = New System.Drawing.Size(625, 381)
        Me.aiuto_gb.TabIndex = 10
        Me.aiuto_gb.TabStop = False
        Me.aiuto_gb.Text = "Informazioni:"
        Me.aiuto_gb.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(347, 353)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(272, 25)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Sebastian Giles 2014-2015"
        '
        'output2_lb
        '
        Me.output2_lb.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.output2_lb.Location = New System.Drawing.Point(17, 112)
        Me.output2_lb.Name = "output2_lb"
        Me.output2_lb.Size = New System.Drawing.Size(620, 39)
        Me.output2_lb.TabIndex = 13
        Me.output2_lb.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.output2_lb.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(653, 547)
        Me.Controls.Add(Me.output2_lb)
        Me.Controls.Add(Me.aiuto_gb)
        Me.Controls.Add(Me.output_lb)
        Me.Controls.Add(Me.calcola_bt)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.a_tb)
        Me.Controls.Add(Me.funzione_tb)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.MinimumSize = New System.Drawing.Size(674, 156)
        Me.Name = "Form1"
        Me.Text = "Test Funzione"
        Me.aiuto_gb.ResumeLayout(False)
        Me.aiuto_gb.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents funzione_tb As System.Windows.Forms.TextBox
    Friend WithEvents a_tb As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents calcola_bt As System.Windows.Forms.Button
    Friend WithEvents output_lb As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents aiuto_gb As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents output2_lb As System.Windows.Forms.Label

End Class
