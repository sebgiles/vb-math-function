﻿Public Class Form1

    'Riferimento all'oggetto della classe Funzione con cui interagisce direttamente il programma
    'In questo caso sarà la funzione inserita dall'utente
    'inizialmente è nullo, non inizializzato
    Private f, d As Funzione

    'Funzione eseguita appena il contenuto della textbox di input per la funzione varia (modificato dall'utente)
    Private Sub funzione_tb_TextChanged(sender As Object, e As EventArgs) Handles funzione_tb.TextChanged
        output2_lb.Text = ""

        'Se l'input per la funzione risulta vuoto il programma si imposta come allo stato iniziale
        If funzione_tb.Text = "" Then
            calcola_bt.Text = "Aiuto"
            output_lb.Text = "Inserisci la funzione"

        Else
            'Se invece contiene una stringa non nulla si procede alla costruzione di un oggetto Funzione usando
            'la stringa stessa
            f = New Funzione(funzione_tb.Text)
            If f.Valida Then
                'Se la stringa era valida e ha dato origine a una funzione valida viene permesso all'utente di
                'calcolare il valore della funzione e l'interfaccia si adatta questo
                calcola_bt.Text = "Calcola"
                output_lb.Text = "Inserisci la variabile"
            Else
                'Se la funzione creata è invalida viene comunicato all'utente
                calcola_bt.Text = "Aiuto"
                output_lb.Text = "La funzione non è valida"
                output2_lb.Visible = False
            End If
        End If

    End Sub

    'Funzione eseguita alla pressione del pulsante 
    'Per tenere traccia di cosa avviene sull'interfaccia utente si utilizza il testo del pulsante stesso
    Private Sub calcola_bt_Click(sender As Object, e As EventArgs) Handles calcola_bt.Click

        If calcola_bt.Text = "Calcola" Then
            'Questo codice viene eseguito quando l'etichetta del bottone mostra la scritta "Calcola" (questo
            'stato si ha solo quando la funzione immessa risulta valida)
            'si legge il valore inserito nella textbox per l'input del valore della variabile con un blocco
            'try catch (argomento trattato analogamente in Java con la professoressa Piersigilli)
            'le istruzioni nel blocco try vengono eseguite "in quarantena" e nel caso di un errore viene eseguito
            'eseguito il blocco catch
            'In questo caso l'eccezione è causata dall'impossibilità di convertire l'input ad un numero reale a 
            'causa dell'inserimento di caratteri non numerici da parte dell'utente
            Dim a As Double
            Try
                'questa istruzione è quella che genera l'eventuale eccezione
                a = a_tb.Text
                'la seguente istruzione non viene eseguita in caso di errore, poichè il processo salta direttamente
                'al blocco catch
                'in una riga calcoliamo il valore di f(a), lo convertiamo in una stringa e lo stampiamo sulla label
                output_lb.Text = "f(" + a_tb.Text + ")= " + CStr(f.Calcola(a))
                d = f.Derivata.Derivata
                If (d.Valida) Then
                    output2_lb.Text = "  f''(" + a_tb.Text + ")= " + CStr(d.Calcola(a))
                    '"f'(x)= " + CStr(d.Espressione) + 
                    ' 
                    output2_lb.Visible = True
                Else
                    output2_lb.Text = "La funzione non è derivabile"
                    output2_lb.Visible = False

                End If

            Catch ex As Exception
                'in caso di errore l'utente viene informato
                output_lb.Text = " l'argomento è invalido"
            End Try


        ElseIf calcola_bt.Text = "Aiuto" Then
            'Questo codice si esegue quando non è attualmente inserita una funzione valida e mostra le "istruzioni
            ' d'uso"
            calcola_bt.Text = "Nascondi"
            aiuto_gb.Visible = True


        ElseIf calcola_bt.Text = "Nascondi" Then
            'Questo codice si esegue quando non è attualmente inserita una funzione valida e le istruzioni sono
            'già visibili: esse vengono nascoste
            calcola_bt.Text = "Aiuto"
            aiuto_gb.Visible = False
        End If
    End Sub

End Class
